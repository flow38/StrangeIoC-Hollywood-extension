﻿using strange.extensions.hollywood.impl;

namespace $rootnamespace$
{
    public class $safeitemname$ : Actor, I$safeitemname$
    {
       
    }
}