﻿using System;
using falcy.strange.extension.hollywood.impl;
using falcy.strange.extensions.hollywood.impl;
using strange.extensions.command.api;
using strange.extensions.command.impl;
using strange.extensions.context.api;
using strange.extensions.context.impl;
using strange.extensions.mediation.api;
using strange.extensions.mediation.impl;
using UnityEngine;

namespace $rootnamespace$
{
    public class $safeitemname$ : HollywoodMVCSContext
    {
        public $safeitemname$(MonoBehaviour view):base(view)
        {

        }

        public $safeitemname$(MonoBehaviour view, ContextStartupFlags flags) : base(view, flags)
        {

        }

        protected override void mapBindings()
        {
            base.mapBindings();

            //Injection binding.
            //Map a mock model and a mock service, both as Singletons
            //Example
            //injectionBinder.Bind<IExampleModel>().To<ExampleModel>().ToSingleton();
            //injectionBinder.Bind<IExampleService>().To<ExampleService>().ToSingleton();

            //Actor/Director binding
            mediationBinder.Bind<SphereActor>().To<SphereDirector>();

            //Event/Command binding
            //Example
       
            //The START event is fired as soon as mappings are complete.
            //Note how we've bound it "Once". This means that the mapping goes away as soon as the command fires.
            //commandBinder.Bind(ContextEvent.START).To<StartCommand>().Once();

            //Game Start Signal
            commandBinder.Bind<MainStartSignal>().To<MainStartCommand>().Once();

        }

        // Unbind the default EventCommandBinder and rebind the SignalCommandBinder
        protected override void addCoreComponents()
        {
            base.addCoreComponents();
            
            //Replace Mediation binding by Director binding
            injectionBinder.Unbind<IMediationBinder>();
            injectionBinder.Bind<IMediationBinder>().To<DirectorBinder>().ToSingleton();
        }
        
    }
}
