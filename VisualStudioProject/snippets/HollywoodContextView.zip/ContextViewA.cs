﻿using falcy.strange.extension.hollywood.impl;

namespace $rootnamespace$
{
    class $safeitemname$ : HollywoodContextView
    {

        public void Awake()
        {
            context = new $safeitemname$(this);
        }
    }
}
