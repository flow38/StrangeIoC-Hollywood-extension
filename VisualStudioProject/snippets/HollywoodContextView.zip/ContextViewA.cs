﻿using strange.extensions.hollywood.impl;

namespace $rootnamespace$
{
    class $safeitemname$ : HollywoodContextView
    {

        public void Awake()
        {
            context = new YourContext(this);
        }
    }
}
